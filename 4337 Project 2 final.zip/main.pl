% Predicate to find the exit in the maze
find_exit(Maze, Actions) :-
    % Find the start coordinates
    find_start(Maze, Start),
    % Attempt to find a path from the start to an exit
    find_path(Maze, Start, Actions).

% Predicate to find the coordinates of the start space
find_start(Maze, Start) :-
    nth0(RowIndex, Maze, Row),
    nth0(ColumnIndex, Row, s),
    Start = (RowIndex, ColumnIndex).

% Predicate to find a path from the start to an exit
find_path(Maze, Current, []) :-
    % Reached an exit
    at_exit(Maze, Current).

find_path(Maze, Current, [Action | RestActions]) :-
    % Move to the next state based on the action
    move(Current, Action, Next),
    % Check if the move is valid and recurse
    is_valid_move(Maze, Next),
    find_path(Maze, Next, RestActions).

% Predicate to check if the current coordinates are at an exit
at_exit(Maze, (Row, Column)) :-
    nth0(Row, Maze, RowList),
    nth0(Column, RowList, e).

% Predicate to check if a move is valid
is_valid_move(Maze, (Row, Column)) :-
    length(Maze, NumRows),
    length(Maze, NumColumns),
    Row >= 0, Row < NumRows,
    Column >= 0, Column < NumColumns,
    nth0(Row, Maze, RowList),
    nth0(Column, RowList, Cell),
    Cell \= w.

% Predicate to define the possible moves
move((Row, Column), left, (Row, NextColumn)) :- NextColumn is Column - 1.
move((Row, Column), right, (Row, NextColumn)) :- NextColumn is Column + 1.
move((Row, Column), up, (NextRow, Column)) :- NextRow is Row - 1.
move((Row, Column), down, (NextRow, Column)) :- NextRow is Row + 1.