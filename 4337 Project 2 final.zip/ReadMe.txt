This is the readme report

I have the source code in .pl and .txt incase if 1 doesnt work the other one should


In order to run this program, the user must first create a maze and a list of actions. Mazes are rows of lists of characters that can be one of three types: walls (w), floors (f), and starting spaces (s). The top row is the leftmost row in the list, while the bottom row is the rightmost row in the list. A maze must have only one starting space and at least one exit in order to be considered valid. Walls cannot be traversed and the cursor cannot go out of bounds. The cursor will always begin at the starting space.

Maze example:
	[[s, f, w], [f, f, e], [w, w, w]]

Actions, on the other hand, are a single row list of words that give instructions to the program on where to move. Valid actions are: left, right, up, and down. If a list of actions does not reach an exit, traverses a wall, or goes out of bounds, then the program will return false. If a list of actions does none of these things and instead ends on an exit space, then the program will return true.

Actions example:
	[down, right, left, up]
