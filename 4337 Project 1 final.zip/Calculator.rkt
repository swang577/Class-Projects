#lang racket
;Start of the program
;Shibo wang, colton lackey
;sxw200032 , crl200002

;Helper function for checking if a character is numeric
(define (char-numeric? c)
  (and (char>=? c #\0) (char<=? c #\9)))

;Function for processing numeric expressions
(define (consume-number expr)
  (let loop ([chars '()]
             [remaining-expr expr]
             [contains-decimal #f]
             [contains-fraction #f]
             [has-digit? #f])
    (if (not (null? remaining-expr))
        (let ([current-char (car remaining-expr)])
          (cond
            [(char-numeric? current-char)
             (loop (cons current-char chars)
                   (cdr remaining-expr)
                   contains-decimal
                   contains-fraction
                   #t)]
            ;This will catch the unexpected trailing characters
            [(char=? current-char #\.)
             (if has-digit?
                 (error "Unexpected trailing characters")
                 (loop (cons current-char chars)
                       (cdr remaining-expr)
                       #t
                       contains-fraction
                       has-digit?))]
            [(char=? current-char #\/)
             (if has-digit?
                 (error "Unexpected trailing characters")
                 (loop (cons current-char chars)
                       (cdr remaining-expr)
                       contains-decimal
                       #t
                       has-digit?))]
            [else
             (let [(value (string->number (list->string (reverse chars))))]
               (if (or contains-decimal contains-fraction)
                   (error "Unexpected trailing characters")
                   (list value remaining-expr)))]))
        (if (not has-digit?)
            (error "Unexpected trailing characters")
            (let [(value (string->number (list->string (reverse chars))))]
              (list value remaining-expr))))))

;Helper function for performing + & * operations 
(define (consume-operation operation expr history)
  (let* [(lhs (eval-expr expr history))]
    (if (null? (cadr lhs))
        (error "Invalid expression")
        (let* [(rhs (eval-expr (cadr lhs) history))]
          (list (operation (car lhs) (car rhs)) (cadr rhs))))))

;Function for evaluating expressions
;This will evaluate the operations and the expressions
(define (eval-expr expr history)
  (cond
    [(char-whitespace? (car expr)) (eval-expr (cdr expr) history)]
    [(char-numeric? (car expr)) (consume-number expr)]
    [(char=? (car expr) #\+)  (consume-operation + (cdr expr) history)]
    [(char=? (car expr) #\*)  (consume-operation * (cdr expr) history)]
    [(char=? (car expr) #\/)  
     (let* [(lhs (eval-expr (cdr expr) history))
            (rhs (eval-expr (cadr lhs) history))]
       (if (= (car rhs) 0)
           (error "Invalid expression")
           (list (/ (car lhs) (car rhs)) (cadr rhs))))]
    [(char=? (car expr) #\-)  
     (let* [(lhs (eval-expr (cdr expr) history))]
       (list (- (car lhs)) (cadr lhs)))]
    [(char=? (car expr) #\$)
     (let* [(result (consume-number (cdr expr)))
            (id (car result))
            (remaining-expr (cadr result))]
       (let [(index (- (length history) id))]
         (if (or (< index 0) (>= index (length history)))
             (error "Invalid reference. Result does not exist.")
             (let [(value (list-ref history index))]
               (list value remaining-expr)))))]
    [(char=? (car expr) #\.)
     (error "Unexpected trailing characters.")]
    [else (error "Invalid Expression")])) 

; Main loop for accepting user input
; Results will be showed in order 
(define (eval-loop history)
  (display "Enter an expression in prefix notation (ex: '+ 1 2', '- 99', '+ $1 2' or 'quit' to exit): ")
  (let [(input (read-line))]
    (if (string=? input "quit")
        (begin
          (displayln "Goodbye!")
          (exit))
        (with-handlers ([exn:fail? (lambda (e)
                             (display "Error: ")
                             (displayln (exn-message e))
                             (eval-loop history))])
          (let* [(expr (string->list input))
                 (result (eval-expr expr history))
                 (value (car result))
                 (remaining-expr (cadr result))]
            
            ; Check for unparsed trailing characters
            (if (not (null? remaining-expr))
                (begin 
                  (displayln "Error: Unexpected trailing characters.")
                  (eval-loop history))
                (let [(value-str (if (rational? value) (rational->string value) (number->string value)))]
                  (displayln (string-append (number->string (+ (length history) 1)) ": " value-str))
                  (eval-loop (cons value history)))))))))


;Function for converting ration numbers to strings
;Return numerator/denominator
(define (rational->string rat)
  (let* [(num (numerator rat))
         (den (denominator rat))]
    (if (= den 1)
        (number->string num)
        (string-append (number->string num) "/" (number->string den)))))

; Start the program
(eval-loop '())