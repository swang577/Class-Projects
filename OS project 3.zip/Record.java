import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Record {
    private long id;
    private String lastName;
    private String firstName;
    private String letterGrade;
    private long overflowLink;

    private static final int LAST_NAME_SIZE = 20;
    private static final int FIRST_NAME_SIZE = 20;
    private static final int LETTER_GRADE_SIZE = 2;
    private static final int RECORD_SIZE = Long.BYTES + LAST_NAME_SIZE + FIRST_NAME_SIZE + LETTER_GRADE_SIZE + Long.BYTES;

    public Record(long id, String lastName, String firstName, String letterGrade) {
        this.id = id;
        this.lastName = truncateOrPad(lastName, LAST_NAME_SIZE);
        this.firstName = truncateOrPad(firstName, FIRST_NAME_SIZE);
        this.letterGrade = truncateOrPad(letterGrade, LETTER_GRADE_SIZE);
        this.overflowLink = -1; // Default value indicating no link
    }

    public Record(byte[] data) {
        deserialize(data);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = truncateOrPad(lastName, LAST_NAME_SIZE);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = truncateOrPad(firstName, FIRST_NAME_SIZE);
    }

    public String getLetterGrade() {
        return letterGrade;
    }

    public void setLetterGrade(String letterGrade) {
        this.letterGrade = truncateOrPad(letterGrade, LETTER_GRADE_SIZE);
    }

    public long getOverflowLink() {
        return overflowLink;
    }

    public void setOverflowLink(long overflowLink) {
        this.overflowLink = overflowLink;
    }

    private String truncateOrPad(String input, int length) {
        if (input.length() > length) {
            return input.substring(0, length);
        } else {
            return String.format("%1$-" + length + "s", input);
        }
    }

    public byte[] serialize() {
        byte[] data = new byte[RECORD_SIZE];
        int offset = 0;

        System.arraycopy(longToBytes(id), 0, data, offset, Long.BYTES);
        offset += Long.BYTES;

        System.arraycopy(padOrTrimBytes(lastName.getBytes(StandardCharsets.UTF_8), LAST_NAME_SIZE), 0, data, offset, LAST_NAME_SIZE);
        offset += LAST_NAME_SIZE;

        System.arraycopy(padOrTrimBytes(firstName.getBytes(StandardCharsets.UTF_8), FIRST_NAME_SIZE), 0, data, offset, FIRST_NAME_SIZE);
        offset += FIRST_NAME_SIZE;

        System.arraycopy(padOrTrimBytes(letterGrade.getBytes(StandardCharsets.UTF_8), LETTER_GRADE_SIZE), 0, data, offset, LETTER_GRADE_SIZE);
        offset += LETTER_GRADE_SIZE;

        System.arraycopy(longToBytes(overflowLink), 0, data, offset, Long.BYTES);

        return data;
    }

    public void deserialize(byte[] data) {
        int offset = 0;

        id = bytesToLong(Arrays.copyOfRange(data, offset, offset + Long.BYTES));
        offset += Long.BYTES;

        lastName = new String(Arrays.copyOfRange(data, offset, offset + LAST_NAME_SIZE), StandardCharsets.UTF_8).trim();
        offset += LAST_NAME_SIZE;

        firstName = new String(Arrays.copyOfRange(data, offset, offset + FIRST_NAME_SIZE), StandardCharsets.UTF_8).trim();
        offset += FIRST_NAME_SIZE;

        letterGrade = new String(Arrays.copyOfRange(data, offset, offset + LETTER_GRADE_SIZE), StandardCharsets.UTF_8).trim();
        offset += LETTER_GRADE_SIZE;

        overflowLink = bytesToLong(Arrays.copyOfRange(data, offset, offset + Long.BYTES));
    }

    private byte[] longToBytes(long value) {
        byte[] bytes = new byte[Long.BYTES];
        for (int i = 0; i < Long.BYTES; i++) {
            bytes[i] = (byte) (value >> (i * 8));
        }
        return bytes;
    }

    private long bytesToLong(byte[] bytes) {
        long value = 0;
        for (int i = 0; i < bytes.length; i++) {
            value |= ((long) bytes[i] & 0xffL) << (i * 8);
        }
        return value;
    }

    private byte[] padOrTrimBytes(byte[] input, int size) {
        byte[] result = new byte[size];
        System.arraycopy(input, 0, result, 0, Math.min(input.length, size));
        Arrays.fill(result, input.length, size, (byte) 0);
        return result;
    }

    public static int getRecordSize() {
        return RECORD_SIZE;
    }

    @Override
    public String toString() {
        return String.format("Record{id=%d, lastName='%s', firstName='%s', letterGrade='%s', overflowLink=%d}",
                id, lastName, firstName, letterGrade, overflowLink);
    }
}
