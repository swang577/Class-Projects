This project involves building a simple database using an indexed sequential file. The database stores student records and uses a B-Tree or B+-Tree for indexing. The program supports adding, deleting, searching, and modifying records.

Files Included

Main.java: Entry point of the program.
Database.java: Contains the primary logic for managing student records.
BTree.java: Implements the B-Tree/B+-Tree data structure for indexing.
Record.java: Defines the structure of a student record.

you can run this program by using the command in the terminal using these 3 lines

javac Main.java Database.java Record.java BTree.java
java Main
java Main students.db

