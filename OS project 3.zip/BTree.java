import java.util.ArrayList;

public class BTree {
    private static final int T = 2; // Minimum degree (T-1 is the minimum number of keys in a node)
    private Node root;

    public BTree() {
        root = new Node();
        root.leaf = true;
    }

    private class Node {
        int n; // Number of keys
        ArrayList<Long> keys = new ArrayList<>();
        ArrayList<Long> values = new ArrayList<>(); // Positions in the file
        ArrayList<Node> children = new ArrayList<>();
        boolean leaf;

        int findKey(long key) {
            for (int i = 0; i < this.n; i++) {
                if (this.keys.get(i) >= key) {
                    return i;
                }
            }
            return this.n;
        }
    }

    public boolean contains(long key) {
        return search(root, key) != null;
    }

    public Long search(long key) {
        return search(root, key);
    }

    private Long search(Node node, long key) {
        int i = 0;
        while (i < node.n && key > node.keys.get(i)) {
            i++;
        }
        if (i < node.n && key == node.keys.get(i)) {
            return node.values.get(i);
        }
        if (node.leaf) {
            return null;
        } else {
            return search(node.children.get(i), key);
        }
    }

    public void insert(long key, long value) {
        Node r = root;
        if (r.n == 2 * T - 1) {
            Node s = new Node();
            root = s;
            s.leaf = false;
            s.children.add(r);
            splitChild(s, 0, r);
            insertNonFull(s, key, value);
        } else {
            insertNonFull(r, key, value);
        }
    }

    private void insertNonFull(Node x, long k, long v) {
        int i = x.n - 1;
        if (x.leaf) {
            x.keys.add(0L);
            x.values.add(0L);
            x.n++;
            while (i >= 0 && k < x.keys.get(i)) {
                x.keys.set(i + 1, x.keys.get(i));
                x.values.set(i + 1, x.values.get(i));
                i--;
            }
            x.keys.set(i + 1, k);
            x.values.set(i + 1, v);
        } else {
            while (i >= 0 && k < x.keys.get(i)) {
                i--;
            }
            i++;
            if (x.children.get(i).n == 2 * T - 1) {
                splitChild(x, i, x.children.get(i));
                if (k > x.keys.get(i)) {
                    i++;
                }
            }
            insertNonFull(x.children.get(i), k, v);
        }
    }

    private void splitChild(Node parent, int i, Node y) {
        Node z = new Node();
        z.leaf = y.leaf;
        z.n = T - 1;
        for (int j = 0; j < T - 1; j++) {
            z.keys.add(y.keys.get(j + T));
            z.values.add(y.values.get(j + T));
        }
        if (!y.leaf) {
            for (int j = 0; j < T; j++) {
                z.children.add(y.children.get(j + T));
            }
        }
        y.n = T - 1;

        parent.children.add(i + 1, z);
        parent.keys.add(i, y.keys.get(T - 1));
        parent.values.add(i, y.values.get(T - 1));
        parent.n++;
    }

    public void traverse() {
        traverse(root);
    }

    private void traverse(Node node) {
        int i;
        for (i = 0; i < node.n; i++) {
            if (!node.leaf) {
                traverse(node.children.get(i));
            }
            System.out.printf("%d ", node.keys.get(i));
        }
        if (!node.leaf) {
            traverse(node.children.get(i));
        }
    }
}
