import java.io.IOException;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        if (args.length < 1) {
            System.err.println("Usage: java Main <filename>.db");
            System.exit(1);
        }

        String baseFilename = args[0].substring(0, args[0].lastIndexOf('.'));
        Database db = new Database(baseFilename);

        try {
            db.initialize();
        } catch (IOException e) {
            System.err.println("Error initializing database: " + e.getMessage());
            System.exit(1);
        }

        String command;
        do {
            System.out.println("\nAvailable commands: add, show, load, merge, quit");
            System.out.print("Enter a command: ");
            command = scanner.nextLine().trim().toLowerCase();

            try {
                switch (command) {
                    case "add":
                        handleAddRecord(db);
                        break;
                    case "show":
                        handleShowRecord(db);
                        break;
                    case "load":
                        handleLoadRecords(db);
                        break;
                    case "merge":
                        db.merge();
                        System.out.println("Database records merged.");
                        break;
                    case "quit":
                        System.out.println("Exiting the program.");
                        break;
                    default:
                        System.out.println("Invalid command. Please try again.");
                }
            } catch (Exception e) {
                System.err.println("Operation failed: " + e.getMessage());
            }
        } while (!command.equals("quit"));

        scanner.close();
    }

    private static void handleAddRecord(Database db) throws IOException {
        System.out.print("Enter ID: ");
        long id = Long.parseLong(scanner.nextLine());
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Letter Grade (e.g., A+, B-): ");
        String letterGrade = scanner.nextLine();

        if (db.addRecord(id, lastName, firstName, letterGrade)) {
            System.out.println("Record added successfully.");
        } else {
            System.out.println("Failed to add record.");
        }
    }

    private static void handleShowRecord(Database db) throws IOException {
        System.out.print("Enter ID to search: ");
        long id = Long.parseLong(scanner.nextLine());
        String record = db.showRecord(id);
        if (record != null) {
            System.out.println("Record found: " + record);
        } else {
            System.out.println("No record found with ID " + id);
        }
    }

    private static void handleLoadRecords(Database db) throws IOException {
        System.out.print("Enter filename to load records from (CSV format): ");
        String filename = scanner.nextLine();
        db.loadRecords(filename);
    }
}
