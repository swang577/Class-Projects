import java.io.*;
import java.util.*;

public class Database {
    private final String dbFilename;
    private final String overflowFilename;
    private final String indexFilename;
    private RandomAccessFile dbFile, overflowFile, indexFile;
    private BTree btree;

    public Database(String baseFilename) {
        this.dbFilename = baseFilename + ".db";
        this.overflowFilename = baseFilename + ".overflow";
        this.indexFilename = baseFilename + ".index";
        this.btree = new BTree();
    }

    public void initialize() throws IOException {
        File db = new File(dbFilename);
        File overflow = new File(overflowFilename);
        File index = new File(indexFilename);

        boolean dbExists = db.exists();
        boolean overflowExists = overflow.exists();
        boolean indexExists = index.exists();

        dbFile = new RandomAccessFile(db, "rw");
        overflowFile = new RandomAccessFile(overflow, "rw");
        indexFile = new RandomAccessFile(index, "rw");

        if (!dbExists || !overflowExists || !indexExists) {
            System.out.println("Creating new database files.");
            if (!indexExists) {
                indexFile.setLength(0);
                indexFile.writeLong(0); // Write an initial value indicating no root
            }
            indexFile.getChannel().force(true);
        }
    }

    public boolean addRecord(long id, String lastName, String firstName, String letterGrade) throws IOException {
        if (btree.contains(id)) {
            System.out.println("Record with ID " + id + " already exists.");
            return false;
        }

        dbFile.seek(dbFile.length());
        Record record = new Record(id, lastName, firstName, letterGrade);
        long position = dbFile.getFilePointer();
        dbFile.write(record.serialize());
        dbFile.getChannel().force(true);

        btree.insert(id, position);
        return true;
    }

    public String showRecord(long id) throws IOException {
        Long position = btree.search(id);
        if (position == null) {
            return null;
        }

        dbFile.seek(position);
        byte[] data = new byte[Record.getRecordSize()];
        dbFile.readFully(data);
        Record record = new Record(data);

        return record.toString();
    }

    public void merge() throws IOException {
        // Read all records from both the main file and overflow file
        Map<Long, Record> allRecords = new TreeMap<>(); // Using a TreeMap to keep them sorted by ID

        // Read records from the main database file
        dbFile.seek(0);
        while (dbFile.getFilePointer() < dbFile.length()) {
            byte[] data = new byte[Record.getRecordSize()];
            dbFile.readFully(data);
            Record record = new Record(data);
            allRecords.put(record.getId(), record);
        }

        // Read records from the overflow file
        overflowFile.seek(0);
        while (overflowFile.getFilePointer() < overflowFile.length()) {
            byte[] data = new byte[Record.getRecordSize()];
            overflowFile.readFully(data);
            Record record = new Record(data);
            allRecords.put(record.getId(), record); // Merge records
        }

        // Clear the main database and overflow files
        dbFile.setLength(0);
        overflowFile.setLength(0);

        // Clear the B-Tree and rebuild it
        btree = new BTree();

        // Write sorted records back to the main database file
        for (Record record : allRecords.values()) {
            long position = dbFile.getFilePointer();
            dbFile.write(record.serialize());
            btree.insert(record.getId(), position);
        }

        dbFile.getChannel().force(true);
        System.out.println("Merge completed successfully. All overflow records have been integrated.");
    }

    public void loadRecords(String filename) throws IOException {
        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("Error: File not found - " + filename);
            return;
        }

        // Reset the database and index before loading new records
        dbFile.setLength(0); // Clear the database file
        overflowFile.setLength(0); // Clear the overflow file
        btree = new BTree(); // Reset the B-Tree index

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    long id = Long.parseLong(parts[0].trim());
                    String lastName = parts[1].trim();
                    String firstName = parts[2].trim();
                    String letterGrade = parts[3].trim();
                    addRecord(id, lastName, firstName, letterGrade);
                } else {
                    System.out.println("Invalid record format: " + line);
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Error parsing ID from file: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    private String formatFixedLengthString(String input, int length) {
        if (input.length() > length) {
            return input.substring(0, length);
        } else {
            return String.format("%1$-" + length + "s", input);
        }
    }
}
