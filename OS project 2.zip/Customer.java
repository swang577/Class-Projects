import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.Semaphore;

public class Customer implements Runnable {
    private final int id;
    Semaphore foodReady = new Semaphore(0);
    Semaphore finishedEating = new Semaphore(0);
    Semaphore waiterAcknowledged = new Semaphore(0);

    public Customer(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        try {
            // Customer sits at a table
            int tableChoice = ThreadLocalRandom.current().nextInt(RestaurantSimulation.NUM_WAITERS);
            RestaurantSimulation.tableSemaphores[tableChoice].acquire();
            RestaurantSimulation.safePrint("Customer " + id + " sits at table " + (tableChoice + 1));

            // Customer places an order
            RestaurantSimulation.orderQueue.put(id);
            RestaurantSimulation.safePrint("Customer " + id + " places an order");

            // Wait for food to be ready
            foodReady.acquire();
            RestaurantSimulation.safePrint("Customer " + id + " has received their food and is now eating.");

            // Simulate eating time
            Thread.sleep(ThreadLocalRandom.current().nextInt(200, 1001));
            finishedEating.release();

            // Wait for waiter to acknowledge
            waiterAcknowledged.acquire();

            // Customer pays and leaves
            RestaurantSimulation.paymentSemaphore.acquire();
            RestaurantSimulation.safePrint("Customer " + id + " is paying and leaving the restaurant");
            Thread.sleep(ThreadLocalRandom.current().nextInt(100, 200)); // Simulate payment time
            RestaurantSimulation.paymentSemaphore.release();

            // Leave the table
            RestaurantSimulation.tableSemaphores[tableChoice].release();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
