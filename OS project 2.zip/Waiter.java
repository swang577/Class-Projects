import java.util.concurrent.ThreadLocalRandom;

public class Waiter implements Runnable {
    private final int id;

    public Waiter(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // Waiter waits for the next order
                Integer customerId = RestaurantSimulation.orderQueue.take();
                if (customerId == -1) { // Check for special value to stop
                    break;
                }

                // Waiter takes the order to the kitchen
                RestaurantSimulation.safePrint("Waiter " + id + " takes Customer " + customerId + "'s order to the kitchen.");
                RestaurantSimulation.kitchenSemaphore.acquire();
                Thread.sleep(ThreadLocalRandom.current().nextInt(100, 501));
                RestaurantSimulation.kitchenSemaphore.release();

                // Signal that the food is ready
                RestaurantSimulation.customers[customerId - 1].foodReady.release();

                // Wait for the customer to finish eating
                RestaurantSimulation.customers[customerId - 1].finishedEating.acquire();
                RestaurantSimulation.safePrint("Waiter " + id + " notes that Customer " + customerId + " has finished eating.");
                RestaurantSimulation.customers[customerId - 1].waiterAcknowledged.release();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            RestaurantSimulation.safePrint("Waiter " + id + " has finished work and is leaving.");
        }
    }
}
