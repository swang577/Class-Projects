README

There is 5 files including this readme file

The 3 java file includes the waiter, customer and restaurantSim
You can compile this code in intellij or any compiler
you can compile using javac RestaurantSimulation.java Customer.java Waiter.java

java RestaurantSimulation

Everything works 