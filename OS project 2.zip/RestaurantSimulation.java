import java.util.concurrent.Semaphore;
import java.util.concurrent.LinkedBlockingQueue;

public class RestaurantSimulation {
    static final int NUM_WAITERS = 3;
    static final int NUM_CUSTOMERS = 40;
    static Semaphore kitchenSemaphore = new Semaphore(1);
    static Semaphore paymentSemaphore = new Semaphore(1);
    static Semaphore[] tableSemaphores = new Semaphore[NUM_WAITERS]; // Assuming one table per waiter
    static Semaphore printSemaphore = new Semaphore(1);
    static LinkedBlockingQueue<Integer> orderQueue = new LinkedBlockingQueue<>();
    static Customer[] customers = new Customer[NUM_CUSTOMERS];

    static {
        for (int i = 0; i < NUM_WAITERS; i++) {
            tableSemaphores[i] = new Semaphore(4, true); // Each table has 4 seats
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] waiters = new Thread[NUM_WAITERS];
        Thread[] customerThreads = new Thread[NUM_CUSTOMERS];

        // Start waiter threads
        for (int i = 0; i < NUM_WAITERS; i++) {
            waiters[i] = new Thread(new Waiter(i + 1)); // Waiter IDs start at 1
            waiters[i].start();
        }

        // Start customer threads and store references to Customer objects
        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            customers[i] = new Customer(i + 1); // Customer IDs start at 1
            customerThreads[i] = new Thread(customers[i]);
            customerThreads[i].start();
            Thread.sleep(50); // Staggered entry
        }

        // Wait for all customer threads to finish
        for (Thread customer : customerThreads) {
            customer.join();
        }

        // Notify waiters to stop after all customers are done
        for (int i = 0; i < NUM_WAITERS; i++) {
            orderQueue.put(-1); // Special value to indicate no more customers
        }

        // Wait for all waiter threads to finish
        for (Thread waiter : waiters) {
            waiter.join();
        }

        safePrint("Simulation complete.");
    }

    public static void safePrint(String message) {
        try {
            printSemaphore.acquire();
            System.out.println(message);
            printSemaphore.release();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
