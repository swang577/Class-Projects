import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java Logger <logFileName>");
            System.exit(1);
        }

        String logFileName = args[0];
        try (Scanner scanner = new Scanner(System.in);
             BufferedWriter writer = new BufferedWriter(new FileWriter(logFileName, true))) {
            while (true) {
                String inputLine = scanner.nextLine();

                // Check for QUIT command to exit the loop
                if ("QUIT".equalsIgnoreCase(inputLine.trim())) {
                    break;
                }

                // Write the log entry with a timestamp
                String logEntry = formatLogEntry(inputLine);
                writer.write(logEntry);
                writer.newLine();
                writer.flush(); // Make sure the log entry is immediately written to the file
            }
        } catch (IOException e) {
            System.err.println("An error occurred while writing to the log file: " + e.getMessage());
        }
    }

    private static String formatLogEntry(String logMessage) {
        // Splitting the log message into ACTION and MESSAGE
        String[] parts = logMessage.split(" ", 2);
        String action = parts[0];
        String message = parts.length > 1 ? parts[1] : ""; // Handle case where there's no message

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String timestamp = now.format(formatter);

        // Adjusting the format to include [ACTION] before the message
        return String.format("%s [%s] %s", timestamp, action, message);
    }
}