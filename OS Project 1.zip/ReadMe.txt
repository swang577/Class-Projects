ReadMe

This is a readme report the the OS project 1. 
In this zip file there is 3 - Java files which is my logger, encryptionProgram and my decryptionProgram
In order to Compile my code you need to go to the terminal and type in the command javac *.java
this process will create .class files for each .java file in the same directory.
after that You can compile using java DriverProgram log.txt

This will run the program, and also create a log.txt that will record all your commands.
Incase you are not able to create the .class files i will have a folder in the zip that includes all the .java .class and log.txt

There is also a PDF that is my write-up for the project
