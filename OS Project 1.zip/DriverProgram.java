import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DriverProgram {

    private static List<String> history = new ArrayList<>();

    public static void main(String[] args) {
        Process encryptionProcess = null;
        Process loggerProcess = null;
        BufferedWriter loggerInput = null;

        try {
            // Start the Logger program process and direct it to log.txt
            ProcessBuilder loggerBuilder = new ProcessBuilder("java", "Logger", "log.txt");
            loggerProcess = loggerBuilder.start();
            loggerInput = new BufferedWriter(new OutputStreamWriter(loggerProcess.getOutputStream()));

            // Start the Encryption program process
            ProcessBuilder encryptionBuilder = new ProcessBuilder("java", "EncryptionProgram");
            encryptionProcess = encryptionBuilder.start();
            Scanner encryptionOutput = new Scanner(encryptionProcess.getInputStream());
            BufferedWriter encryptionInput = new BufferedWriter(new OutputStreamWriter(encryptionProcess.getOutputStream()));
            Scanner userInput = new Scanner(System.in);

            logAction(loggerInput, "Driver Program started.");

            // Handle commands and responses
            processCommands(userInput, encryptionInput, encryptionOutput, loggerInput);

            logAction(loggerInput, "Driver Program terminated.");

        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (encryptionProcess != null) encryptionProcess.destroy();
            if (loggerProcess != null) loggerProcess.destroy();
        }
    }

    private static void processCommands(Scanner userInput, BufferedWriter encryptionInput, Scanner encryptionOutput, BufferedWriter loggerInput) throws IOException {
        while (true) {
            System.out.println("\nEnter command (password, encrypt, decrypt, history, quit):");
            String input = userInput.nextLine().trim();

            logAction(loggerInput, "User command: " + input); // Log user command

            if ("quit".equalsIgnoreCase(input)) {
                sendCommand(encryptionInput, "QUIT");
                sendCommand(loggerInput, "QUIT"); // Make sure to log before quitting
                break;
            } else if ("history".equalsIgnoreCase(input)) {
                displayHistory();
                continue;
            }

            String commandToSend = determineCommand(input, userInput);
            if (commandToSend == null) {
                continue;
            }

            sendCommand(encryptionInput, commandToSend);
            String response = displayResponse(encryptionOutput);

            if (response != null && !response.startsWith("ERROR")) {
                history.add("Command: " + commandToSend + " | Response: " + response);
                logAction(loggerInput, "Action successful: " + commandToSend + " | Response: " + response); // Log successful action
            } else if (response != null) {
                logAction(loggerInput, "Action failed: " + commandToSend + " | Response: " + response); // Log failed action
            }
        }
    }

    private static void sendCommand(BufferedWriter writer, String command) throws IOException {
        writer.write(command);
        writer.newLine();
        writer.flush();
    }

    private static String displayResponse(Scanner scanner) {
        if (scanner.hasNextLine()) {
            String response = scanner.nextLine();
            System.out.println("Response: " + response);
            return response;
        }
        return null;
    }

    private static void logAction(BufferedWriter loggerInput, String action) throws IOException {
        sendCommand(loggerInput, action);
    }

    private static void displayHistory() {
        if (history.isEmpty()) {
            System.out.println("No history available.");
        } else {
            System.out.println("Command and Response History:");
            history.forEach(System.out::println);
        }
    }

    private static String determineCommand(String input, Scanner userInput) {
        String command = null;
        switch (input.toLowerCase()) {
            case "password":
                System.out.println("Enter new passkey:");
                String passkey = userInput.nextLine().trim();
                command = "PASSKEY " + passkey;
                break;
            case "encrypt":
            case "decrypt":
                System.out.println("Enter string to " + input + ":");
                String text = userInput.nextLine().trim();
                command = input.toUpperCase() + " " + text;
                break;
            default:
                System.out.println("Invalid command. Please try again.");
                break;
        }
        return command;
    }
}
