import java.util.Scanner;

public class EncryptionProgram {
    private static String passkey = "";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNextLine()) {
            String input = scanner.nextLine().trim();
            if ("QUIT".equalsIgnoreCase(input)) {
                break;
            }

            String[] parts = input.split(" ", 2);
            String command = parts[0];
            String argument = parts.length > 1 ? parts[1] : "";

            switch (command.toUpperCase()) {
                case "PASSKEY":
                    passkey = argument;
                    System.out.println("RESULT Passkey set.");
                    break;
                case "ENCRYPT":
                    if (passkey.isEmpty()) {
                        System.out.println("ERROR Passkey not set");
                    } else {
                        String encrypted = processText(argument, true);
                        System.out.println("RESULT " + encrypted);
                    }
                    break;
                case "DECRYPT":
                    if (passkey.isEmpty()) {
                        System.out.println("ERROR Passkey not set");
                    } else {
                        String decrypted = processText(argument, false);
                        System.out.println("RESULT " + decrypted);
                    }
                    break;
                default:
                    System.out.println("ERROR Unknown command.");
            }
        }
        scanner.close();
    }

    private static String processText(String text, boolean encrypt) {
        StringBuilder result = new StringBuilder();
        for (int i = 0, j = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetter(c)) {
                c = (char) (c - (Character.isUpperCase(c) ? 'A' : 'a'));
                int shift = passkey.charAt(j % passkey.length()) - (Character.isUpperCase(passkey.charAt(j % passkey.length())) ? 'A' : 'a');
                if (encrypt) {
                    c = (char) ((c + shift + 26) % 26);
                } else {
                    c = (char) ((c - shift + 26) % 26);
                }
                c = (char) (c + (Character.isUpperCase(text.charAt(i)) ? 'A' : 'a'));
                j++;
            }
            result.append(c);
        }
        return result.toString();
    }
}
