#Shibo Wang, sxw200032
#get the input from the user, and divide the array received to 
#single elements, merge the arrays and save to list
#print the list at the end

.data	
input1:	.asciiz "Enter a length:\n"	#input1
input2:	.asciiz "Enter array elements(write single element per line):\n"	#input2
result:	.asciiz "The Result is:\n"	#result of string data
space:	.asciiz " "			#string data space
list:	.word	32			#values of input array 
array:	.space	128			#final array values
length:	.word	10

	.text
	.globl main
main:
	li 	$v0, 4		#print the string
	la 	$a0, input1	#save address of input1 to #a0
	syscall			#print value in #a0 
	
	li	$v0, 5		#get integer 
	syscall			#get from keyboard
	add 	$s1, $v0, $zero	#save value to address of #s1
	sw	$s1, length	#store value of $s1 to length
	
        sll	$a0 $v0 2	#number of bytes in $a0
        li 	$v0 9		#allocate bytes
        syscall			#address of $v0
        sw	$a0, list	#store the size to the array
        la	$v1, list	#save address of array to $v1
	
	
	li 	$v0, 4		#print the string
	la 	$a0, input2	#save input2 to #a0
	syscall			#print value #a0 holds
	
	add	$t2,$zero,$zero	#set $t0 = 0
	j	while		#goes to "while"
	
while:
	beq	$t2,$s1,check	#check for the condition and if it is, go to check
	li	$v0, 5		#get integer 
	syscall			#get from keyboard
	add	$t1, $v0, $zero	#save value to $t1
	
	sw	$t1, 0($v1)	#save to array
	
	addi	$v1, $v1, 4	#go to next array
	
	addi	$t2, $t2, 1	#count variables.
	j	while		#go to "while" 
	
check:	
	la	$a0, list	#save to $a0
	lw	$t0, length	#save length to $t0
	sll	$t0, $t0, 2	#Multiply the array length by 4
	add	$a1, $a0, $t0	#Calculate array and end address
	jal	mergesort	#go to mergesort, and come back
  	b	sortend		#go to sortend to mark complete
	
mergesort:

	addi	$sp, $sp, -16	#Adjust stack pointer
	sw	$ra, 0($sp)	#Store return address on the stack
	sw	$a0, 4($sp)	#Store array start address on the stack
	sw	$a1, 8($sp)	#Store array end address on the stack
	
	sub 	$t0, $a1, $a0	#save end address-start address to $t0

	ble	$t0, 4, mergesortend	#If met condition then just return
	
	srl	$t0, $t0, 3	#Divide the array size by 8 to half the number of elements 
	sll	$t0, $t0, 2	#Multiple number by 4 to get half of the array size  
	add	$a1, $a0, $t0	#Calculate midpoint address of the array
	sw	$a1, 12($sp)	#Store the array midpoint address on the stack
	
	jal	mergesort	#Call on the first half of the array
	
	lw	$a0, 12($sp)	#Load the midpoint address of the array from the stack
	lw	$a1, 8($sp)	#Load the end address of the array from the stack
	
	jal	mergesort	#Call recursively on the second half of the array
	
	lw	$a0, 4($sp)	#Load the array start address from the stack
	lw	$a1, 12($sp)	#Load the array midpoint address from the stack
	lw	$a2, 8($sp)	#Load the array end address from the stack
	
	jal	merge		#Merge the two array halves
	
mergesortend:				

	lw	$ra, 0($sp)	#Load the return address from the stack
	addi	$sp, $sp, 16	#Adjust the stack pointer
	jr	$ra		#Return 
	
merge:
	addi	$sp, $sp, -16	#Adjust the stack pointer
	sw	$ra, 0($sp)	#Store the return address on the stack
	sw	$a0, 4($sp)	#Store the start address on the stack
	sw	$a1, 8($sp)	#Store the midpoint address on the stack
	sw	$a2, 12($sp)	#Store the end address on the stack
	
	move	$s0, $a0	#Create copy of the first half address
	move	$s1, $a1	#Create copy of the second half address
	
mergeloop:

	lw	$t0, ($s0)	#Load first half position value
	lw	$t1, ($s1)	#Load second half position value
	
	
	bgt	$t1, $t0, noshift	#If value is smaller and infront, don't shift
	
	move	$a0, $s1	#Load argument for the element to move
	move	$a1, $s0	#Load argument for the address to move it to
	jal	shift		#Shift element to the new position 
	
	addi	$s1, $s1, 4	#Increment second half index
noshift:
	addi	$s0, $s0, 4	#Increment first half index
	
	lw	$a2, 12($sp)	#Reload the end address
	bge	$s0, $a2, mergeloopend	#End loop when both halves are empty
	bge	$s1, $a2, mergeloopend	#End loop when both halves are empty
	b	mergeloop	#go to mergeloop
	
mergeloopend:
	
	lw	$ra, 0($sp)	#Load return address
	addi	$sp, $sp, 16	#Adjust stack pointer
	jr 	$ra		#Return

shift:
	ble	$a0, $a1, shiftend	#If condition is met then stop shifting
	addi	$t6, $a0, -4	#Find previous address in the array
	lw	$t7, 0($a0)	#Get current pointer
	lw	$t8, 0($t6)	#Get previous pointer
	sw	$t7, 0($t6)	#Save current pointer to the previous 
	sw	$t8, 0($a0)	#Save previous pointer to the current address
	move	$a0, $t6	#Shift current position back
	b 	shift		#go to shift

shiftend:
	jr	$ra		#Return
	
sortend:			#jump when sorting is complete

	add	$t2,$zero,$zero	#set $t2 = 0
	add	$t3,$zero,$zero	#set $t3 = 0
	lw	$t0, length	#set value of length to $t0
	li 	$v0, 4		#print the string
	la 	$a0, result	#set address of result to #a0
	syscall			#print #a0 
print:
	beq	$t2,$t0,exit	#if condition is met, exit
	lw	$t6, list($t3)	#save value at index  $t3/4  to $t6
	addi	$t3, $t3, 4	# $t3 save next index value
	addi	$t2, $t2, 1	# $t2 save the number of elements passed
	li	$v0, 1		#print integer
	addi	$a0, $t6, 0	#save $a0 with the value of $t6
	syscall			#print $a0
	li 	$v0, 4		#print string
	la 	$a0, space	#save address of space to #a0
	syscall			#print value in address #a0 holds
	j	print		#repeat print
	
exit:
	li	$v0,10		#exit
	syscall			#exit
