# Question 1 Part 1: The program will square the inputed value 

# Question 1 Part 2: 

	  .data	

arg :	.word 8  #argument 1
arg2:   .word 3  #argument 2

	.text
	.globl main
main:
	la	$t1, arg	      #store arg to $t1
	lw	$s1, 0($t1)       #store value of $t1 to $s1
	la    	$t1, arg2	#store arg2 to $t1
	lw	$t1, 0($t1)	      #store value of arg2 to $t1

	addi	$s3, $zero, 0     #$s3 == 0
	beqz	$t1, fin	      #if $t1 is 0, then go to final	
fori:
	add	$s3, $s3, $s1	  #add s1 and s3 and save to s3
	addi	$t1, $t1, -1	  #save t1 as t1-1
	bnez	$t1, fori	        #if t1 != 0, go to fori
	
	li 	$v0, 1		  #print integer
	add     $a0, $s3,$zero	  #print the result
  	syscall			  #exit
		
fin:
	li	$v0, 10		  #exit
	syscall			  #exit
