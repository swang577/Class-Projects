        .data	

arg1:	.asciiz "Enter the First Number : \n"	#string data arg1
arg2:	.asciiz "Enter the Second Number: \n"	#string data arg2
result:	.asciiz "The Result is: \n"		#string data result

	.text
	.globl main
main:
	li $v0, 4		       #print string
	la $a0, arg1		 #store address of input1 to #a0
	syscall			 #print value of #a0 
	
	li	$v0, 5		 #get integer 
	syscall			 #get from user
	add 	$s1, $v0, $zero    #store value to #s1
	
	li $v0, 4		       #print string
	la $a0, arg2		 #store address of arg2 to #a0
	syscall			 #print value in #a0 
	
	li	$v0, 5		 #get integer
	syscall			 #get from user
	add	$t1, $v0, $zero	 #store value to $t1
	
	slt	$t3, $s1, $zero	  #if $s1 > #zero, #t3 = 0
	bne	$t3, $zero, zero1	  #if $t3 != 0, goes to zero1
	j	check		        #checks
zero1:
	add	$s1, $zero, $zero  #set $s1 == 0
	j	check		        #checks
zero2:
	add	$t1, $zero, $zero	#set $t1 to 0
	j	sequence	        #go to sequence

check:	
	slt	$t3, $t1, $zero	  #if $t1 is greater then #zero, #t3 = 0
	bne	$t3, $zero, zero2	  #if $t3 != 0, go to zero2
sequence:
	addi	$s3, $zero, 0	  #set $s3 to 0
	beqz	$t1, fin	        #if $t1 == 0, go to final	
		
fori:
	add	$s3, $s3, $s1	  #add s1 and s3 and store value to s3
	addi	$t1, $t1, -1	  #store t1 as t1-1
	bnez	$t1, fori	        #if t1 != 0, go to fori
	
fin:
	li $v0, 4		        #print string
	la $a0, result		  #store address of result to #a0
	syscall			  #print value in address #a0
	
	li 	$v0, 1		  #print integer
	add 	$a0, $s3, $zero     #print result
	syscall			  #syscall print the integer of result
	
	li	$v0, 10		  
	syscall			  #exit
