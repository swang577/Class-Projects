        .data	
N:	.word	9
Result:	.word	0

sum:	.asciiz  "The Result is: \n"
	.text
	.globl main
main:
	la	$t1, N		   #get address of N and store to $t1
	lw	$t1, 0($t1)	   #get value of $t1
		
	slt	$t3, $t1, $zero	   #if $s1 is greater then $zero, $t3 = 0
	bne	$t3, $zero, zero   #if $t3 is not equal to 0, go to zero
	j	check		   #go to check
zero:
	add	$t1, $zero, $zero  #set $t1 to 0
	j	check		   #go to check

even:
	addi	$t1, $t1, -1	 #set $t1 to $t1-1, as $t1 is odd number, and we want even number
	j	sequence	 #go to sequence

check:	
	andi	$t3, $t1, 1	 #if $t1 is even, $t3 = 0
	bne	$t3, $zero, even #if $t3 != 0, go to even
sequence:
	addi	$s3, $zero, 0	#set $s3 to 0(notA)
	beqz	$t1, fin	#if $t1 == 0, go to fin 	
		
fori:
	add	$s3, $s3, $t1	#add s1 and s3 and save to s3
	addi	$t1, $t1, -2	#save t1 as t1-1
	bnez	$t1, fori	#if t1 is not equal to 0, go to fori
	
fin:
	li $v0, 4		#print string
	la $a0, sum		#get address of sum and save to $a0
	syscall			#print $a0
	
	sw	$a3, Result	#save integer got to Result
	li 	$v0, 1		#print integer
	add 	$a0, $s3, $zero	#print result
	syscall			#syscall print integer of result
	
	li	$v0, 10		#exit
	syscall			#exit
