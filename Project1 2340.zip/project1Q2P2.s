            .data	
N:	      .word	8
Result:	.word	0
input:	.asciiz "Enter a Value:\n"
sum:	      .asciiz "The Result is:\n"
error:	.asciiz "invalid input!"
	      .text
	      .globl main
main:
	li $v0, 4
	la $a0, input
	syscall

	li	$v0, 5		#get value
	syscall			#get from user input
	add 	$t1, $v0, $zero	#store value to #s1
	
	slt	$t3, $t1, $zero	#if $t1 > $zero, $t3 = 0
	bne	$t3, $zero, zero	#if $t3 != 0, go to zero
	j	check		      #checks
zero:
	li $v0, 4		      #print string
	la $a0, error		#save address of error to $a0
	syscall			#print value of error
	addi	$t1, $zero, -1	#set $t1 == -1
	add	$a3, $t1, $zero	#set $a3 == -1
	sw	$a3, Result  	#store $a3 to Result
	li	$v0, 10		
	syscall			#quit

even:
	addi	$t1, $t1, -1	#set $t1 == 0
	j	seq	      #go to seq

check:	
	andi	$t3, $t1, 1	      #if $t1 > #zero, #t3 = 0
	bne	$t3, $zero, even	#if $t3 != 0, go to even
seq:
	addi	$s3, $zero, 0	#set $s3 to 0
	beqz	$t1, final	      #if $t1 == 0, go to final 	
		
fori:
	add	$s3, $s3, $t1	#add s1 and s3 and store to s3
	addi	$t1, $t1, -2	#save t1 == t1-1
	bnez	$t1, fori	      #if t1 != 0, go to fori
	
final:
	li $v0, 4		      #print string
	la $a0, sum		      #store address of sum to #a0
	syscall			#print value in #a0
	
	sw	$a3, Result  	#store integer and go to Result

	li 	$v0, 1		#print integer
	add 	$a0, $s3, $zero	#print result
	syscall			

	li	$v0, 10		
	syscall			#exit
